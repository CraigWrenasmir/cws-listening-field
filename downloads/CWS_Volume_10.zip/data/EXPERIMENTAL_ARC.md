# Continuing into advanced repertoire

Craig's latest instruction: more jazz elements, dreamlike flowing sequences and experimentation, with pieces becoming more experimental as the library grows and moving beyond the original beginner/intermediate framing.

This instruction supersedes the playing-level clause in the original Op. 7–300 goal. Keep the 294-piece commission, existing music, four-page maximum, 256 sounded-onset maximum, two-word titles, stable numeric stamps and GitHub Pages publication.

## Provisional compositional direction

- Begin the transition at Op. 21: longer irregular spans, displaced entrances, wider jazz voicings, more active inner/bass lines and greater use of space across the keyboard. Preserve clear melodic ideas and slow, breathing performances.
- Develop genuine rhythmic independence and counterpoint as the run continues: tuplets against a steady lower voice, phrases with different lengths in the hands, more substantial register changes and layered motifs. Extend notation/timing support and verify it before using a new device publicly.
- Later works can move further into chromatic relationships, shifting tonal centres, more demanding textures and freer form. The collection's overall trajectory should become more adventurous, while allowing quieter works to provide contrast.
- Keep expressive purpose explicit for each piece. Increasing the number of notes, sharps or difficult leaps alone does not constitute development. No arbitrary note permutations or whole-piece transposition batches.

## Technical review

Op. 1–20 keep their existing music and limits. New pieces declare a difficulty description, specific technical features and gesture limits appropriate to their writing. These limits are review thresholds, not proof of human playability. Inspect complete scores, review hand shapes and transitions, preserve accurate MIDI/score timing, and retain the four-page/onset constraints. Do not silently roll a chord or redistribute it between hands without matching notation. Keyboard/listening feedback remains outstanding.

The names and musical ancestry remain part of the same library. Continue the sequential completion/checkpoint workflow in `data/PROGRESS.md`; revise this direction in response to Craig's feedback.

## Second Studies pilot

Craig approved Op. 201–205 as five pilots, with longer developing forms, more daylight and dynamic contrast, and more varied endings. Second Studies permit six printed pages and 768 sounded pitch onsets, usually 2–5 minutes. First Studies (Op. 1–200) remain complete and unchanged. Kinship retains exact ancestry while showing two connected series regions. Stop at 205 and seek listening feedback before extending the series.
